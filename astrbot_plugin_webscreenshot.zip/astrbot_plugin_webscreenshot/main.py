import asyncio
import io
import re
import time
from urllib.parse import quote

import aiohttp

from astrbot.api import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.event.filter import EventMessageType
from astrbot.api.star import Context, Star, register
from astrbot.core.message.components import Image, Plain
from astrbot.core.message.message_event_result import MessageChain

# 匹配三类链接:带协议头 / www开头 / 常见后缀的裸域名(如 baidu.com、zhihu.com/xxx)
URL_RE = re.compile(
    r"(?:https?://[^\s<>\"'()，。,;！？]+"
    r"|www\.[^\s<>\"'()，。,;！？]+"
    r"|[a-zA-Z0-9][-a-zA-Z0-9]*\.(?:com|cn|net|org|gov|edu|io|ai|cc|xyz|top|me|tv"
    r"|info|biz|co|shop|site|online|vip|icu|link|app|dev|moe|live|pro|wiki|news"
    r"|blog|tech|store|space|cloud)(?:\.cn)?(?:/[^\s<>\"'()，。,;！？]*)?)",
    re.IGNORECASE,
)

# 解析插件成功发送的标志:视频/语音组件
MEDIA_TYPES = {"Video", "Record"}

# 「万能解析器」(astrbot_plugin_parser) 负责的平台域名,命中则默认让路
DEFAULT_SKIP_DOMAINS = [
    "bilibili.com", "b23.tv", "bilibili.cn",
    "douyin.com", "iesdouyin.com",
    "xiaohongshu.com", "xhslink.com",
    "weibo.com", "weibo.cn",
    "x.com", "twitter.com", "t.co",
    "pixiv.net",
    "kuaishou.com",
    "acfun.cn", "aixifan.com",
    "qzone.qq.com",
    "xiaoheihe.com", "xiaoheihe.cn",
]

DEFAULT_API = "https://api.microlink.io/?url={url}&screenshot=true&embed=screenshot.url&screenshot.timeout=30000"
DEFAULT_BACKUP_API = "https://image.thum.io/get/width/800/{raw_url}"


@register(
    "astrbot_plugin_webscreenshot",
    "Balji",
    "被@且消息(或被引用消息)包含链接时自动生成网页截图;解析插件负责的域名让路,解析失败自动兜底截图",
    "1.1.0",
)
class WebScreenshotPlugin(Star):
    def __init__(self, context: Context, config=None):
        super().__init__(context)
        cfg = config or {}
        self.require_at = bool(cfg.get("require_at", True))
        self.cooldown = int(cfg.get("cooldown", 300))
        self.timeout = int(cfg.get("timeout", 30))
        if self.timeout == 60:
            # 旧版默认60秒,迁移为30秒;用户显式想要60可在配置中改回
            logger.info("[webscreenshot] 检测到旧默认超时60秒,已按新默认30秒运行")
            self.timeout = 30
        self.show_hint = bool(cfg.get("show_hint", True))
        self.api_template = str(cfg.get("screenshot_api", DEFAULT_API))
        self.backup_api_template = str(cfg.get("backup_screenshot_api", DEFAULT_BACKUP_API))
        # 旧版配置迁移:thum.io 模板误用了编码占位符,自动纠正
        if "thum.io" in self.backup_api_template and "{url}" in self.backup_api_template:
            logger.warning("[webscreenshot] 检测到旧版备用截图模板,已自动迁移为 {raw_url} 形式")
            self.backup_api_template = self.backup_api_template.replace(
                "https://image.thum.io/get/width/800/{url}", DEFAULT_BACKUP_API
            ).replace("{url}", "{raw_url}")
        self.retry_delay = float(cfg.get("retry_delay", 2))
        self.fallback_enabled = bool(cfg.get("fallback_on_parser_fail", True))
        self.fallback_wait = int(cfg.get("fallback_wait", 15))
        skip = cfg.get("skip_domains", DEFAULT_SKIP_DOMAINS)
        self.skip_domains = [str(d).lower() for d in (skip or DEFAULT_SKIP_DOMAINS)]
        self._last_shot = {}      # (session_id, url) -> 触发时间戳
        self._media_replied = {}  # message_id -> 时间戳(该消息已被解析插件回复过视频/语音)
        self._bg_tasks = set()

    # ---------------- 解析结果探测 ----------------

    @filter.on_decorating_result()
    async def _record_media_reply(self, event: AstrMessageEvent):
        """记录每条消息是否产生了视频/语音类回复(解析插件成功的标志)。"""
        try:
            result = event.get_result()
            if not result:
                return
            chain = getattr(result, "chain", None) or getattr(result, "result_chain", None) or []
            for seg in chain:
                if getattr(seg, "type", "") in MEDIA_TYPES:
                    key = self._msg_key(event)
                    self._media_replied[key] = time.time()
                    if len(self._media_replied) > 2000:
                        cutoff = time.time() - 3600
                        self._media_replied = {
                            k: v for k, v in self._media_replied.items() if v > cutoff
                        }
                    break
        except Exception as e:
            logger.debug(f"[webscreenshot] 记录媒体回复失败: {e}")

    @staticmethod
    def _msg_key(event: AstrMessageEvent) -> str:
        return str(getattr(event.message_obj, "message_id", "") or event.unified_msg_origin)

    def _parser_replied_media(self, event: AstrMessageEvent) -> bool:
        return self._msg_key(event) in self._media_replied

    # ---------------- 工具函数 ----------------

    @staticmethod
    def _normalize_url(u: str) -> str:
        """清理尾部标点;裸域名(无协议头)自动补 https:// 前缀。"""
        u = (u or "").strip().rstrip(".,;:!?)]}”』》〉")
        if u and not u.lower().startswith(("http://", "https://")):
            u = "https://" + u
        return u

    def _handled_by_parser(self, url: str) -> bool:
        low = url.lower()
        return any(dom in low for dom in self.skip_domains)

    def _pick_url(self, urls) -> str:
        """选第一个不是解析插件负责域名的链接(规范化后),全是则返回空串(让路)。"""
        for u in urls:
            u = self._normalize_url(u)
            if u.startswith("http") and not self._handled_by_parser(u):
                return u
        return ""

    async def _url_from_reply(self, event: AstrMessageEvent) -> str:
        """取出被引用消息的文本(仅 aiocqhttp/NapCat 等平台可用,失败静默)。"""
        seq = None
        for seg in event.message_obj.message or []:
            if getattr(seg, "type", "") == "Reply":
                seq = getattr(seg, "id", None)
                break
        if not seq:
            return ""
        bot = getattr(event, "bot", None)
        if bot is None:
            return ""
        try:
            if hasattr(bot, "get_msg"):
                data = await bot.get_msg(message_id=seq)
            elif hasattr(bot, "api"):
                data = await bot.api.call_action("get_msg", message_id=seq)
            else:
                return ""
        except Exception as e:
            logger.debug(f"[webscreenshot] 获取被引用消息失败: {e}")
            return ""
        if not data:
            return ""
        msg = data.get("message", "")
        if isinstance(msg, str):
            return msg
        if isinstance(msg, list):
            parts = []
            for item in msg:
                if isinstance(item, dict):
                    for v in (item.get("data") or {}).values():
                        if isinstance(v, str):
                            parts.append(v)
            return " ".join(parts)
        return ""

    def _is_blank_image(self, data: bytes) -> bool:
        """近全白图片检测(依赖 Pillow,未安装时跳过检测)。"""
        try:
            from PIL import Image
        except ImportError:
            return False
        try:
            img = Image.open(io.BytesIO(data)).convert("L").resize((48, 48))
            pixels = list(img.getdata())
            n = len(pixels)
            mean = sum(pixels) / n
            var = sum((p - mean) ** 2 for p in pixels) / n
            return mean > 228 and var < 40
        except Exception:
            return False

    async def _fetch_once(self, template: str, url: str) -> bytes:
        """用给定模板请求一次截图服务,失败抛异常。

        {url} 替换为URL编码后的目标地址(query参数型服务,如 microlink);
        {raw_url} 替换为原始地址(路径拼接型服务,如 thum.io)。
        """
        target = template.replace("{url}", quote(url, safe="")).replace("{raw_url}", url)
        async with aiohttp.ClientSession() as session:
            async with session.get(
                target, timeout=aiohttp.ClientTimeout(total=self.timeout)
            ) as resp:
                body = await resp.read()
                if resp.status != 200:
                    raise RuntimeError(f"截图服务返回 HTTP {resp.status}")
                if "json" in resp.headers.get("Content-Type", ""):
                    raise RuntimeError("截图服务返回了JSON而非图片（可能额度用尽或目标网页无法渲染）")
                if self._is_blank_image(body):
                    raise RuntimeError("渲染结果疑似空白页（目标网站可能反爬或需要登录）")
                return body

    async def _screenshot(self, url: str) -> bytes:
        """主服务尝试2次,失败后换备用服务再尝试2次,全部失败抛出最后一次的异常。"""
        templates = [(self.api_template, "主")]
        if self.backup_api_template and self.backup_api_template != self.api_template:
            templates.append((self.backup_api_template, "备用"))
        last_err: Exception = RuntimeError("无可用截图服务")
        for template, label in templates:
            for attempt in (1, 2):
                try:
                    return await self._fetch_once(template, url)
                except asyncio.TimeoutError:
                    last_err = RuntimeError(f"{label}服务超时（超过{self.timeout}秒）")
                    logger.warning(f"[webscreenshot] {label}服务第{attempt}次尝试超时: {url}")
                except Exception as e:
                    last_err = RuntimeError(f"{label}服务失败：{e}")
                    logger.warning(f"[webscreenshot] {label}服务第{attempt}次尝试失败: {url} -> {e}")
                if attempt == 1 and self.retry_delay > 0:
                    await asyncio.sleep(self.retry_delay)
        raise last_err

    def _in_cooldown(self, key) -> bool:
        now = time.time()
        if now - self._last_shot.get(key, 0) < self.cooldown:
            return True
        if len(self._last_shot) > 2000:
            self._last_shot = {
                k: v for k, v in self._last_shot.items() if now - v < self.cooldown
            }
        self._last_shot[key] = now
        return False

    async def _send_screenshot(self, event: AstrMessageEvent, url: str):
        """冷却检查并发送提示;实际截图在后台完成后主动发送,避免长时间重试导致回复丢失。"""
        if self._in_cooldown((event.message_obj.session_id, url)):
            return
        if self.show_hint:
            yield event.plain_result("正在生成网页截图，大约需要几秒到十几秒……")
        task = asyncio.create_task(self._deliver_screenshot(event, url))
        self._bg_tasks.add(task)
        task.add_done_callback(self._task_done)

    async def _deliver_screenshot(self, event: AstrMessageEvent, url: str):
        """后台完成截图,并主动发送图片或失败原因(不受事件管道生命周期影响)。"""
        umo = event.unified_msg_origin
        try:
            img = await self._screenshot(url)
        except Exception as e:
            logger.error(f"[webscreenshot] 截图最终失败 {url}: {e}")
            try:
                await self.context.send_message(
                    umo, MessageChain(chain=[Plain(f"网页截图失败，已依次重试主/备用截图服务：{e}")])
                )
            except Exception as send_err:
                logger.error(f"[webscreenshot] 失败提示发送失败: {send_err}")
            return
        try:
            await self.context.send_message(umo, MessageChain(chain=[Image.fromBytes(img)]))
        except Exception as send_err:
            logger.error(f"[webscreenshot] 截图发送失败: {send_err}")
            try:
                await self.context.send_message(
                    umo,
                    MessageChain(chain=[Plain("截图已生成但发送失败，请稍后重试或联系管理员查看日志")]),
                )
            except Exception:
                pass

    async def _fallback_later(self, event: AstrMessageEvent, url: str):
        """后台兜底:等待解析插件处理,若其已发出视频/语音则退让,否则截图。"""
        try:
            logger.info(f"[webscreenshot] 兜底任务已排定:{url}({self.fallback_wait}秒后检查解析结果)")
            await asyncio.sleep(max(0, self.fallback_wait))
            if self._parser_replied_media(event):
                logger.info(f"[webscreenshot] 解析插件已处理该链接,跳过兜底: {url}")
                return
            if self._in_cooldown((event.message_obj.session_id, url)):
                logger.info(f"[webscreenshot] 链接处于冷却期,跳过兜底: {url}")
                return
            logger.info(f"[webscreenshot] 解析插件未出结果,开始兜底截图: {url}")
            umo = event.unified_msg_origin
            if self.show_hint:
                await self.context.send_message(
                    umo, MessageChain(chain=[Plain("解析插件似乎没有出结果，兜底生成网页截图……")])
                )
            await self._deliver_screenshot(event, url)
        except Exception as e:
            logger.error(f"[webscreenshot] 兜底任务失败 {url}: {e}")

    # ---------------- 事件处理 ----------------

    @filter.event_message_type(EventMessageType.ALL)
    async def on_message(self, event: AstrMessageEvent):
        if self.require_at and not event.is_at_or_wake_command:
            return
        urls = URL_RE.findall(event.message_str or "")
        if not urls:
            # 当前消息没有链接,看是不是引用了一条带链接的消息
            quoted = await self._url_from_reply(event)
            if not quoted:
                return
            urls = URL_RE.findall(quoted)
        if not urls:
            return
        url = self._pick_url(urls)
        if url:
            # 普通网页链接:直接截图
            async for result in self._send_screenshot(event, url):
                yield result
            return
        # 链接全是解析插件负责的域名:不立即处理,后台等解析结果,失败则兜底
        if not self.fallback_enabled:
            return
        fallback_url = self._normalize_url(urls[0])
        if not fallback_url.startswith("http"):
            return
        task = asyncio.create_task(self._fallback_later(event, fallback_url))
        self._bg_tasks.add(task)
        task.add_done_callback(self._task_done)

    def _task_done(self, task: asyncio.Task):
        self._bg_tasks.discard(task)
        if not task.cancelled() and task.exception() is not None:
            logger.error(f"[webscreenshot] 兜底任务异常退出: {task.exception()}")
    @filter.command("截图")
    async def force_screenshot(self, event: AstrMessageEvent, url: str = ""):
        """强制对指定网址截图(忽略域名让路)。用法: /截图 https://example.com"""
        url = self._normalize_url(url)
        if not url.lower().startswith("http") or "." not in url:
            yield event.plain_result("用法：/截图 https://example.com")
            return
        async for result in self._send_screenshot(event, url):
            yield result
